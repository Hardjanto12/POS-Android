<?php
include "koneksi.php";

date_default_timezone_set("Asia/Bangkok");
// $query = "SELECT Nomor FROM p_notransaksi ORDER BY Nomor DESC LIMIT 1";

$query = "SELECT TOP 1 Nomor FROM p_notransaksi ORDER BY Nomor DESC";
$data = sqlsrv_query($koneksi,$query);
$result = sqlsrv_fetch_array($data);

while($result){
	echo date("dmY");
	echo "/",$result["Nomor"];
}

?>