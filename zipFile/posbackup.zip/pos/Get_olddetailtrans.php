<?php
include "koneksi.php";

$noTransaksi = $_GET['noTransaksi'];

date_default_timezone_set("Asia/Bangkok");
$data = mysqli_query($koneksi,"SELECT noTransaksi,totalBayar,kembalian,diskon FROM t_transaksi WHERE `noTransaksi` = '$noTransaksi'");

while($result=mysqli_fetch_array($data)){
	echo $result["noTransaksi"];
	echo "*";
	echo $result["totalBayar"];
	echo "*";
	echo $result["kembalian"];
	echo "*";
	echo $result["diskon"];
}

?>