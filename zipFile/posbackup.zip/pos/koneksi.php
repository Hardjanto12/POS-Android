<?php 
  $koneksi=mysqli_connect("localhost","id18315622_testing2","f&p[-=C@!Y9FdtFI","id18315622_test2");

  if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
// Check connection
//if ($koneksi->connect_error) {
//  die("Connection failed: " . $koneksi->connect_error);
//}
//echo "Connected successfully";

?>