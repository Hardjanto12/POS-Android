<?php
include "koneksi.php";

date_default_timezone_set("Asia/Bangkok");
$data = mysqli_query($koneksi,"SELECT Nomor FROM p_notransaksi ORDER BY Nomor DESC LIMIT 1");


while($result=mysqli_fetch_array($data)){
	echo date("dmY");
	echo "/",$result["Nomor"];
}

?>