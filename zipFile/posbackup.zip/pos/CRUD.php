<?php
include "koneksi.php";

   $ID         = $_GET['ID'];
   $idBarang   = $_GET['idBarang'];
   $nmBarang   = $_GET['nmBarang'];
   $hargaPokok = $_GET['hargaPokok'];
   $hargaJual  = $_GET['hargaJual'];
   $expDate    = $_GET['expDate'];
   $stok       = $_GET['stok'];

date_default_timezone_set("Asia/Bangkok");
//	$tanggal= date("Y/m/d"); 

   // SAVE DATA
if ($ID=='SAVE') {
  $simpan = mysqli_query($koneksi, "INSERT INTO t_BARANG(idBarang,nmBarang,hargaPokok,hargaJual,expDate,stok)
  values('$idBarang','$nmBarang','$hargaPokok','$hargaJual','$expDate','$stok')");

  if($simpan) {
     echo "Succesfull";
   }else
   {
     echo "UnSuccesfull";  
   }
}

if ($ID=='UPDATE_DATA') {
    $data=mysqli_query($koneksi, "UPDATE t_barang SET nmBarang='$nmBarang',hargaPokok='$hargaPokok',hargaJual='$hargaJual',expDate='$expDate',stok=$stok where idBarang=$idBarang");
   
        
   if ($data) {
      echo "Succesfull";
   }else
   {
      echo "UnSuccesfull";  
   }
}   

if ($ID=='DELETE_DATA') {
   $data=mysqli_query($koneksi, "DELETE FROM t_barang where idBarang=$idBarang");
        
   if ($data) {
      echo "Succesfull";
   }else
   {
      echo "UnSuccesfull";  
   }

}   

?>