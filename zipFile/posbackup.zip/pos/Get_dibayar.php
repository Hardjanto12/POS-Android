<?php
include "koneksi.php";

$noTransaksi = $_GET['noTransaksi'];

date_default_timezone_set("Asia/Bangkok");
$data = mysqli_query($koneksi,"SELECT noTransaksi,( Tunai + Debit + Emoney) AS Pembayaran FROM t_transaksi WHERE `noTransaksi` = '$noTransaksi'");

while($result=mysqli_fetch_array($data)){
	echo $result["noTransaksi"];
	echo "*";
	echo $result["Pembayaran"];
}

?>