<?php
   include "koneksi.php";  

   $NoUrut  =$_GET['NoUrut'];
   $idBarang=$_GET['idBarang'];   
   $nmBarang=$_GET['nmBarang']; 
   $harga   =$_GET['harga'];
   $jumlah   =$_GET['jumlah'];
   $noTransaksi=$_GET['NoTransaksi'];
   $userKasir  =$_GET['userKasir'];


   $tanggal= date("Y/m/d"); 
   //$jumlah =1;
   $total  = $jumlah * $harga;
   
   $data=mysqli_query($koneksi,"SELECT * FROM t_tempkasir WHERE idBarang=$idBarang"); 
   if (mysqli_num_rows($data) == 0)
   {
      $simpan = mysqli_query($koneksi, "INSERT INTO t_tempkasir(No,noTransaksi,tanggal,idBarang,nmBarang,jumlah,harga,total,ID_Kasir)
      values('$NoUrut','$noTransaksi','$tanggal','$idBarang','$nmBarang','$jumlah','$harga','$total','$userKasir') ORDER BY No");

      if($simpan) {
        echo "BERHASIL SIMPAN";
        mysqli_query($koneksi,"SET @num := 0");
	    mysqli_query($koneksi,"UPDATE t_tempkasir SET No = @num := (@num+1)");
	    mysqli_query($koneksi,"ALTER TABLE t_tempkasir AUTO_INCREMENT = 1");
         

      }else
      {
         echo "GAGAL SIMPAN";
      }
   }else
   {
      echo 'UPDATE';
      while($hasil=mysqli_fetch_array($data)){
        $jumlah = $hasil["jumlah"] + 1; 
        $total  = $jumlah * $harga;  
   }
      mysqli_query($koneksi, "UPDATE t_tempkasir SET jumlah=$jumlah,total=$total where idBarang=$idBarang");     
   }

?>