<?php
include "koneksi.php";

$ID = $_GET['ID'];

date_default_timezone_set("Asia/Bangkok");

$hapus=mysqli_query($koneksi,"DELETE FROM t_tempkasir WHERE No=$ID");
if($hapus){
	echo "Data Sudah Terhapus";
	mysqli_query($koneksi,"SET @num := 0");
	mysqli_query($koneksi,"UPDATE t_tempkasir SET No = @num := (@num+1)");
	mysqli_query($koneksi,"ALTER TABLE t_tempkasir AUTO_INCREMENT = 1");
}	
?>